#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  7 13:36:12 2022

@author: fatimagarcia

"""
import datetime



 

class Cliente():

    def __init__(self,nombre,email,direccion,key):
        self.nombre = nombre
        self. email = email
        self.key=key
        self. direccion = direccion
        self.listacompra=[]
        self.fecha= datetime.datetime.now()
    def setNewemail(self,Newemail):
        self.email=Newemail
    def setNewdireccion(self,Newdireccion):
        self.direccion= Newdireccion
    def sumarlibro(self,titulolibro):
        
        self.listacompra.append(titulolibro)
    def quitarlibro(self,titulolibro):

        self.listacompra.remove(titulolibro)
    def setNewkey(self,Newkey):
        self.setNewkey=Newkey

        
        
        
    def compra (self,libro):
        pass

C1=Cliente('Luis Bravo Collado','bravocollado','001','pablo tejera')
C2=Cliente('Fatima Garcia Aguado','fgaga','002','pie de altar')        
