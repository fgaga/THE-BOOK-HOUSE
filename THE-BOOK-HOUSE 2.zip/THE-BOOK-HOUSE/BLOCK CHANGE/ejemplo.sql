SELECT Email,Idcliente FROM cliente;
INSERT INTO cliente 
VALUES ("fatima1", "direccion1",  "mail", "12");