#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 26 19:21:56 2022

@author: scotty
"""
from pymongo import MongoClient
import pymongo
import datasetToObjetos as data

import pathlib
import sys
modelos=str(pathlib.Path(__file__).parent.parent.parent.absolute())+'/MODELOS' 
sys.path.append(modelos)
import cliente as C
def get_database():
    

    # Provide the mongodb atlas url to connect python to mongodb using pymongo
    CONEXION_BBDD= "mongodb+srv://fgaga:123456789hola@cluster0.iiqes.mongodb.net"

    # Create a connection using MongoClient. You can import MongoClient or use pymongo.MongoClient 
    client = MongoClient(CONEXION_BBDD)

    # Create the database for our example (we will use the same database throughout the tutorial
    return client['Book_House']
    
 
dbname = get_database()


def meterAutor(autor):
    collection_name = dbname["autor"]
    try:
        collection_name.insert_one(autor.__dict__)
    except:
        print('yA LO TENEMOS CHIQUI')
def meterAutores():    
    for i in data.conjuntoAutores:
        meterAutor(i)
        
collection_clientes= dbname['clientes']
collection_clientes.insert_one(C.C1.__dict__)#introduce los datos que hemos puesto antes en C1
collection_clientes.insert_one(C.C2.__dict__)#introduce los datos que hemos puesto antes en C1




