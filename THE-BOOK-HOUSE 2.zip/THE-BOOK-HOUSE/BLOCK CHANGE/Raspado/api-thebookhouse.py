#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 11:34:55 2022

@author: fatimagarcia
"""
from email.mime import application
from urllib import response
from flask import *
from flask_pymongo import PyMongo
from bson import json_util

app= Flask(__name__)

app.config['MONGO_URI']='mongodb+srv://fgaga:123456789hola@cluster0.iiqes.mongodb.net/Book_House'
mongo=PyMongo(app)
@app.route ('/CLIENTE/<NOMBRE>',methods=[' GET ','POST'])
def get_user(nombre): 
    user=mongo.db.users.find_one({'nombre':nombre})  
    response=json_util.dumps(user) 
    return Response (response,mimetype='application/json')
@app.route ('/CLIENTE/<NOMBRE>',methods=[' POST '])
def get_user(nombre): 
    user=mongo.db.users.find_one({'nombre':nombre})  
    response=json_util.dumps(user) 
    return Response (response,mimetype='application/json')

if __name__=="__main__":
    app.run(debug=1,port=3000)
