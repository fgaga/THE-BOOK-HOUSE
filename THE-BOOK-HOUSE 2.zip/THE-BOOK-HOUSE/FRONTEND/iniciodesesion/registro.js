var dominios= ["gmail.com","hotmail.com","yahoo.es"]


function paraver(){
    console.log('HOLA MUNDO!!!!!')

}